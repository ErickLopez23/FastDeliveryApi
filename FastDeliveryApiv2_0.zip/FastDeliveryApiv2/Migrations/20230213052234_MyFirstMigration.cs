﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

#pragma warning disable CA1814 // Prefer jagged arrays over multidimensional

namespace FastDeliveryApi.Migrations
{
    /// <inheritdoc />
    public partial class MyFirstMigration : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DeleteData(
                table: "Customers",
                keyColumn: "Id",
                keyValue: 1);

            migrationBuilder.DeleteData(
                table: "Customers",
                keyColumn: "Id",
                keyValue: 2);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.InsertData(
                table: "Customers",
                columns: new[] { "Id", "Address", "CreatedOnUtc", "Email", "ModifiedOnUtc", "Name", "PhoneNumberCustomer", "Status" },
                values: new object[,]
                {
                    { 1, "San Miguel", new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified), "suleyma@univo.edu.sv", null, "Suleyma Lopez", "0000-0000", true },
                    { 2, "San Miguel", new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified), "kvasquez@univo.edu.sv", null, "Kevin Vasquez", "2200-5500", true }
                });
        }
    }
}
